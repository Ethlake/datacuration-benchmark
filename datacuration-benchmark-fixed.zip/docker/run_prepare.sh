#!/bin/bash
set -euo pipefail
CONFIG_PATH="${1:-/workspace/pipeline.yaml}"
cd /workspace
conda run --no-capture-output -n train python prepare_assets.py --config "$CONFIG_PATH"

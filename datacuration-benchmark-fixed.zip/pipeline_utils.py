from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict

import yaml


class ConfigError(ValueError):
    pass


def load_config(config_path: str | Path) -> tuple[Dict[str, Any], Path, Path]:
    config_path = Path(config_path).expanduser().resolve()
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    if not isinstance(cfg, dict):
        raise ConfigError("pipeline.yaml 顶层必须是字典。")

    project_root_raw = cfg.get("project_root", ".")
    project_root = _resolve_path(project_root_raw, config_path.parent)
    return cfg, config_path, project_root



def _resolve_path(raw: str | Path, base_dir: Path) -> Path:
    path = Path(raw).expanduser()
    if not path.is_absolute():
        path = (base_dir / path)
    return path.resolve()



def resolve_paths(cfg: Dict[str, Any], config_dir: Path, project_root: Path) -> Dict[str, Path]:
    if "paths" not in cfg:
        raise ConfigError("pipeline.yaml 缺少 paths 段。")

    required = [
        "data_root",
        "dataset_dir",
        "dataset_json_path",
        "image_root",
        "model_root",
        "vicuna_path",
        "vision_tower_path",
        "mm_projector_path",
        "trained_model_dir",
        "eval_work_dir",
        "lmu_data_root",
    ]
    paths_cfg = cfg["paths"]
    missing = [k for k in required if k not in paths_cfg]
    if missing:
        raise ConfigError(f"pipeline.yaml 缺少这些 paths 键: {missing}")

    base_dir = project_root
    return {k: _resolve_path(v, base_dir) for k, v in paths_cfg.items()}



def validate_config(cfg: Dict[str, Any], paths: Dict[str, Path]) -> None:
    downloads = cfg.get("downloads", {})
    dataset_id = downloads.get("dataset_id")
    if not dataset_id:
        raise ConfigError("pipeline.yaml 缺少 downloads.dataset_id")

    expected_dataset_dir = paths["data_root"] / "download" / dataset_id
    if paths["dataset_dir"] != expected_dataset_dir:
        raise ConfigError(
            "pipeline.yaml 路径不一致：\n"
            f"  paths.dataset_dir = {paths['dataset_dir']}\n"
            f"  但按 data_root + dataset_id 推导应该是 {expected_dataset_dir}"
        )

    expected_dataset_json = expected_dataset_dir / "llava_v1_5_mix665k.json"
    if paths["dataset_json_path"] != expected_dataset_json:
        raise ConfigError(
            "pipeline.yaml 路径不一致：\n"
            f"  paths.dataset_json_path = {paths['dataset_json_path']}\n"
            f"  但按数据集结构推导应该是 {expected_dataset_json}"
        )

    if paths["image_root"] != expected_dataset_dir:
        raise ConfigError(
            "pipeline.yaml 路径不一致：\n"
            f"  paths.image_root = {paths['image_root']}\n"
            f"  对 LLaVA v1.5 instruct，应该等于 dataset_dir = {expected_dataset_dir}"
        )

    model_ids = downloads.get("model_ids", [])
    model_root = paths["model_root"]
    model_expected = {
        "vicuna-7b-v1.5": model_root / "download" / "vicuna-7b-v1.5",
        "clip-vit-large-patch14-336": model_root / "download" / "clip-vit-large-patch14-336",
        "llava-v1.5-mlp2x-336px-pretrain-vicuna-7b-v1.5": model_root / "download" / "llava-v1.5-mlp2x-336px-pretrain-vicuna-7b-v1.5",
    }

    for mid in model_ids:
        if mid not in model_expected:
            raise ConfigError(f"暂不支持的 model_id: {mid}")

    if "vicuna-7b-v1.5" in model_ids and paths["vicuna_path"] != model_expected["vicuna-7b-v1.5"]:
        raise ConfigError(
            "pipeline.yaml 路径不一致：paths.vicuna_path 应该等于 model_root/download/vicuna-7b-v1.5"
        )
    if "clip-vit-large-patch14-336" in model_ids and paths["vision_tower_path"] != model_expected["clip-vit-large-patch14-336"]:
        raise ConfigError(
            "pipeline.yaml 路径不一致：paths.vision_tower_path 应该等于 model_root/download/clip-vit-large-patch14-336"
        )

    expected_projector = (
        model_expected["llava-v1.5-mlp2x-336px-pretrain-vicuna-7b-v1.5"] / "mm_projector.bin"
    )
    if paths["mm_projector_path"] != expected_projector:
        raise ConfigError(
            "pipeline.yaml 路径不一致：paths.mm_projector_path 应该指向 model_root/download/"
            "llava-v1.5-mlp2x-336px-pretrain-vicuna-7b-v1.5/mm_projector.bin"
        )



def ensure_parent_dirs(paths: Dict[str, Path]) -> None:
    keys = ["data_root", "model_root", "trained_model_dir", "eval_work_dir", "lmu_data_root"]
    for key in keys:
        path = paths[key]
        if key.endswith("_dir") and key not in {"trained_model_dir", "eval_work_dir"}:
            path.mkdir(parents=True, exist_ok=True)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)



def require_existing(path: Path, label: str) -> None:
    if not path.exists():
        raise FileNotFoundError(f"{label} 不存在: {path}")



def pretty_paths(paths: Dict[str, Path]) -> str:
    lines = []
    for k in sorted(paths):
        lines.append(f"- {k}: {paths[k]}")
    return "\n".join(lines)

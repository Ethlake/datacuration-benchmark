from __future__ import annotations

import argparse
import os
import shutil
import subprocess
from pathlib import Path

from pipeline_utils import (
    ConfigError,
    ensure_parent_dirs,
    load_config,
    pretty_paths,
    require_existing,
    resolve_paths,
    validate_config,
)



def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run training and evaluation from pipeline.yaml")
    parser.add_argument("--config", default="pipeline.yaml", help="Path to pipeline.yaml")
    return parser.parse_args()



def _find_conda() -> str:
    candidates = [shutil.which("conda"), "/opt/conda/bin/conda"]
    for cand in candidates:
        if cand and Path(cand).exists():
            return cand
    raise RuntimeError("找不到 conda，可执行本脚本时请放在 docker 容器内运行。")



def main() -> None:
    args = parse_args()
    cfg, config_path, project_root = load_config(args.config)
    paths = resolve_paths(cfg, config_path.parent, project_root)
    validate_config(cfg, paths)
    ensure_parent_dirs(paths)

    train_cfg = cfg.get("train", {})
    eval_cfg = cfg.get("eval", {})
    train_script = Path(train_cfg.get("script", ""))
    if not train_script.is_absolute():
        train_script = (project_root / train_script).resolve()

    if not train_script.exists():
        raise FileNotFoundError(f"train.script 不存在: {train_script}")

    require_existing(paths["dataset_json_path"], "训练 JSON")
    require_existing(paths["image_root"], "图片根目录")
    require_existing(paths["vicuna_path"], "Vicuna 模型目录")
    require_existing(paths["vision_tower_path"], "Vision tower 目录")
    require_existing(paths["mm_projector_path"], "mm_projector.bin")

    trained_model_dir = paths["trained_model_dir"]
    trained_model_dir.parent.mkdir(parents=True, exist_ok=True)
    paths["eval_work_dir"].mkdir(parents=True, exist_ok=True)
    paths["lmu_data_root"].mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["DCBENCH_PROJECT_ROOT"] = str(project_root)
    env["DCBENCH_BASE_LLM_PATH"] = str(paths["vicuna_path"])
    env["DCBENCH_DATA_PATH"] = str(paths["dataset_json_path"])
    env["DCBENCH_IMAGE_FOLDER"] = str(paths["image_root"])
    env["DCBENCH_VISION_TOWER_PATH"] = str(paths["vision_tower_path"])
    env["DCBENCH_MM_PROJECTOR_PATH"] = str(paths["mm_projector_path"])
    env["DCBENCH_TRAINED_MODEL_DIR"] = str(trained_model_dir)

    print("[Run] project_root:", project_root)
    print("[Run] resolved paths:\n" + pretty_paths(paths))
    print(f"\n[Run] Start training with: {train_script}")
    subprocess.run(["bash", str(train_script)], cwd=str(project_root), env=env, check=True)

    require_existing(trained_model_dir, "训练输出目录")

    conda_exe = _find_conda()
    eval_script = project_root / "eval" / "run_eval.py"
    if not eval_script.exists():
        raise FileNotFoundError(f"评测脚本不存在: {eval_script}")

    datasets = eval_cfg.get("datasets", [])
    if not datasets:
        raise ConfigError("pipeline.yaml 缺少 eval.datasets")

    eval_cmd = [
        conda_exe,
        "run",
        "--no-capture-output",
        "-n",
        "eval",
        "python",
        str(eval_script),
        "--model-path",
        str(trained_model_dir),
        "--datasets",
        *datasets,
        "--work-dir",
        str(paths["eval_work_dir"]),
        "--lmu-data-root",
        str(paths["lmu_data_root"]),
        "--gpu",
        str(eval_cfg.get("gpu", "0")),
        "--model-name",
        str(eval_cfg.get("model_name", "llava_v1.5_7b")),
        "--mode",
        str(eval_cfg.get("mode", "all")),
    ]

    print(f"\n[Run] Start evaluation with env `eval`")
    print("[Run] Eval command:")
    print(" ".join(eval_cmd))
    subprocess.run(eval_cmd, cwd=str(project_root), env=env, check=True)

    print("\n[Run] All done.")


if __name__ == "__main__":
    main()

# Adopted from https://github.com/lm-sys/FastChat. Below is the original copyright:
# Adopted from tatsu-lab@stanford_alpaca. Below is the original copyright:
#    Copyright 2023 Rohan Taori, Ishaan Gulrajani, Tianyi Zhang, Yann Dubois, Xuechen Li
#
#    Licensed under the Apache License, Version 2.0 (the "License");
#    you may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.
import copy
import json
import logging
import os
import pathlib
from dataclasses import dataclass, field
from datasets import load_from_disk, Dataset, DatasetDict, concatenate_datasets  # NEW
from typing import Dict, List, Optional, Sequence
from transformers import TrainerCallback

import tokenizers
import torch
import transformers
from packaging import version
from PIL import Image
from torch.utils.data import Dataset
from datasets import load_from_disk  # 新增

from llava import conversation as conversation_lib
from llava.constants import (DEFAULT_IM_END_TOKEN, DEFAULT_IM_START_TOKEN,
                             DEFAULT_IMAGE_TOKEN, IGNORE_INDEX,
                             IMAGE_TOKEN_INDEX)
from llava.mm_utils import process_anyres_image, tokenizer_image_token
from llava.model import *
from llava.train.llava_trainer import LLaVATrainer

local_rank = None


def rank0_print(*args):
    if local_rank == 0:
        print(*args)


IS_TOKENIZER_GREATER_THAN_0_14 = version.parse(
    tokenizers.__version__) >= version.parse('0.14')


@dataclass
class ModelArguments:
    model_name_or_path: Optional[str] = field(default="facebook/opt-125m")
    version: Optional[str] = field(default="v0")
    freeze_backbone: bool = field(default=False)
    tune_mm_mlp_adapter: bool = field(default=False)
    vision_tower: Optional[str] = field(default=None)
    mm_vision_select_layer: Optional[int] = field(
        default=-1)   # default to the last layer
    pretrain_mm_mlp_adapter: Optional[str] = field(default=None)
    mm_projector_type: Optional[str] = field(default='linear')
    mm_use_im_start_end: bool = field(default=False)
    mm_use_im_patch_token: bool = field(default=True)
    mm_patch_merge_type: Optional[str] = field(default='flat')
    mm_vision_select_feature: Optional[str] = field(default="patch")


@dataclass
class DataArguments:
    data_path: str = field(default=None,
                           metadata={"help": "Path to the training data."})
    lazy_preprocess: bool = False
    is_multimodal: bool = False
    image_folder: Optional[str] = field(default=None)
    image_aspect_ratio: str = 'square'


@dataclass
class TrainingArguments(transformers.TrainingArguments):
    cache_dir: Optional[str] = field(default=None)
    optim: str = field(default="adamw_torch")
    remove_unused_columns: bool = field(default=False)
    freeze_mm_mlp_adapter: bool = field(default=False)
    unfreeze_mm_vision_tower: bool = field(default=False)
    mpt_attn_impl: Optional[str] = field(default="triton")
    model_max_length: int = field(
        default=512,
        metadata={
            "help":
            "Maximum sequence length. Sequences will be right padded (and possibly truncated)."
        },
    )
    double_quant: bool = field(
        default=True,
        metadata={
            "help": "Compress the quantization statistics through double quantization."}
    )
    quant_type: str = field(
        default="nf4",
        metadata={
            "help": "Quantization data type to use. Should be one of `fp4` or `nf4`."}
    )
    bits: int = field(
        default=16,
        metadata={"help": "How many bits to use."}
    )
    lora_enable: bool = False
    lora_r: int = 64
    lora_alpha: int = 16
    lora_dropout: float = 0.05
    lora_weight_path: str = ""
    lora_bias: str = "none"
    lora_qv_proj_only: bool = False
    mm_projector_lr: Optional[float] = None
    mm_vision_tower_lr: Optional[float] = None
    group_by_modality_length: bool = field(default=False)


def maybe_zero_3(param, ignore_status=False, name=None):
    from deepspeed import zero
    from deepspeed.runtime.zero.partition_parameters import ZeroParamStatus
    if hasattr(param, "ds_id"):
        if param.ds_status == ZeroParamStatus.NOT_AVAILABLE:
            if not ignore_status:
                logging.warning(
                    f"{name}: param.ds_status != ZeroParamStatus.NOT_AVAILABLE: {param.ds_status}")
        with zero.GatheredParameters([param]):
            param = param.data.detach().cpu().clone()
    else:
        param = param.detach().cpu().clone()
    return param


# Borrowed from peft.utils.get_peft_model_state_dict
def get_peft_state_maybe_zero_3(named_params, bias):
    if bias == "none":
        to_return = {k: t for k, t in named_params if "lora_" in k}
    elif bias == "all":
        to_return = {k: t for k,
                     t in named_params if "lora_" in k or "bias" in k}
    elif bias == "lora_only":
        to_return = {}
        maybe_lora_bias = {}
        lora_bias_names = set()
        for k, t in named_params:
            if "lora_" in k:
                to_return[k] = t
                bias_name = k.split("lora_")[0] + "bias"
                lora_bias_names.add(bias_name)
            elif "bias" in k:
                maybe_lora_bias[k] = t
        for k, t in maybe_lora_bias:
            if bias_name in lora_bias_names:
                to_return[bias_name] = t
    else:
        raise NotImplementedError
    to_return = {k: maybe_zero_3(v, ignore_status=True)
                 for k, v in to_return.items()}
    return to_return


def get_peft_state_non_lora_maybe_zero_3(named_params, require_grad_only=True):
    to_return = {k: t for k, t in named_params if "lora_" not in k}
    if require_grad_only:
        to_return = {k: t for k, t in to_return.items() if t.requires_grad}
    to_return = {k: maybe_zero_3(v, ignore_status=True).cpu()
                 for k, v in to_return.items()}
    return to_return


def get_mm_adapter_state_maybe_zero_3(named_params, keys_to_match):
    to_return = {k: t for k, t in named_params if any(
        key_match in k for key_match in keys_to_match)}
    to_return = {k: maybe_zero_3(v, ignore_status=True).cpu()
                 for k, v in to_return.items()}
    return to_return


def get_vision_tower_state_maybe_zero_3(named_params, keys_to_match=['']):
    to_return = {k: t for k, t in named_params if any(
        key_match in k for key_match in keys_to_match)}
    to_return = {k: maybe_zero_3(v, ignore_status=True).cpu()
                 for k, v in to_return.items()}
    return to_return


def find_all_linear_names(model, qv_proj_only=False):
    if qv_proj_only:
        rank0_print('Only add LoRA to QV proj')
        return ['q_proj', 'v_proj']
    cls = torch.nn.Linear
    lora_module_names = set()
    multimodal_keywords = ['mm_projector', 'vision_tower', 'vision_resampler']
    for name, module in model.named_modules():
        if any(mm_keyword in name for mm_keyword in multimodal_keywords):
            continue
        if isinstance(module, cls):
            names = name.split('.')
            lora_module_names.add(names[0] if len(names) == 1 else names[-1])

    if 'lm_head' in lora_module_names:  # needed for 16-bit
        lora_module_names.remove('lm_head')
    return list(lora_module_names)


def safe_save_model_for_hf_trainer(trainer: transformers.Trainer,
                                   output_dir: str):
    """Collects the state dict and dump to disk."""

    if getattr(trainer.args, "tune_mm_mlp_adapter", False):
        # Only save Adapter
        keys_to_match = ['mm_projector']
        if getattr(trainer.args, "use_im_start_end", False):
            keys_to_match.extend(['embed_tokens', 'embed_in'])

        weight_to_save = get_mm_adapter_state_maybe_zero_3(
            trainer.model.named_parameters(), keys_to_match)
        trainer.model.config.save_pretrained(output_dir)

        current_folder = output_dir.split('/')[-1]
        parent_folder = os.path.dirname(output_dir)
        if trainer.args.local_rank == 0 or trainer.args.local_rank == -1:
            if current_folder.startswith('checkpoint-430'):
                mm_projector_folder = os.path.join(
                    parent_folder, "mm_projector")
                os.makedirs(mm_projector_folder, exist_ok=True)
                torch.save(weight_to_save, os.path.join(
                    mm_projector_folder, f'{current_folder}.bin'))
            else:
                torch.save(weight_to_save, os.path.join(
                    output_dir, f'mm_projector.bin'))
        return

    if trainer.deepspeed:
        torch.cuda.synchronize()
        trainer.save_model(output_dir)
        return

    state_dict = trainer.model.state_dict()
    if trainer.args.should_save:
        cpu_state_dict = {
            key: value.cpu()
            for key, value in state_dict.items()
        }
        del state_dict
        trainer._save(output_dir, state_dict=cpu_state_dict)  # noqa


def smart_tokenizer_and_embedding_resize(
    special_tokens_dict: Dict,
    tokenizer: transformers.PreTrainedTokenizer,
    model: transformers.PreTrainedModel,
):
    """Resize tokenizer and embedding.

    Note: This is the unoptimized version that may make your embedding size not be divisible by 64.
    """
    num_new_tokens = tokenizer.add_special_tokens(special_tokens_dict)
    model.resize_token_embeddings(len(tokenizer))

    if num_new_tokens > 0:
        input_embeddings = model.get_input_embeddings().weight.data
        output_embeddings = model.get_output_embeddings().weight.data

        input_embeddings_avg = input_embeddings[:-num_new_tokens].mean(
            dim=0, keepdim=True)
        output_embeddings_avg = output_embeddings[:-num_new_tokens].mean(
            dim=0, keepdim=True)

        input_embeddings[-num_new_tokens:] = input_embeddings_avg
        output_embeddings[-num_new_tokens:] = output_embeddings_avg


def _tokenize_fn(strings: Sequence[str],
                 tokenizer: transformers.PreTrainedTokenizer) -> Dict:
    """Tokenize a list of strings."""
    tokenized_list = [
        tokenizer(
            text,
            return_tensors="pt",
            padding="longest",
            max_length=tokenizer.model_max_length,
            truncation=True,
        ) for text in strings
    ]
    input_ids = labels = [
        tokenized.input_ids[0] for tokenized in tokenized_list
    ]
    input_ids_lens = labels_lens = [
        tokenized.input_ids.ne(tokenizer.pad_token_id).sum().item()
        for tokenized in tokenized_list
    ]
    return dict(
        input_ids=input_ids,
        labels=labels,
        input_ids_lens=input_ids_lens,
        labels_lens=labels_lens,
    )


def _mask_targets(target, tokenized_lens, speakers):
    # cur_idx = 0
    cur_idx = tokenized_lens[0]
    tokenized_lens = tokenized_lens[1:]
    target[:cur_idx] = IGNORE_INDEX
    for tokenized_len, speaker in zip(tokenized_lens, speakers):
        if speaker == "human":
            target[cur_idx+2:cur_idx + tokenized_len] = IGNORE_INDEX
        cur_idx += tokenized_len


def _add_speaker_and_signal(header, source, get_conversation=True):
    """Add speaker and start/end signal on each round."""
    BEGIN_SIGNAL = "### "
    END_SIGNAL = "\n"
    conversation = header
    for sentence in source:
        from_str = sentence["from"]
        if from_str.lower() == "human":
            from_str = conversation_lib.default_conversation.roles[0]
        elif from_str.lower() == "gpt":
            from_str = conversation_lib.default_conversation.roles[1]
        else:
            from_str = 'unknown'
        sentence["value"] = (BEGIN_SIGNAL + from_str + ": " +
                             sentence["value"] + END_SIGNAL)
        if get_conversation:
            conversation += sentence["value"]
    conversation += BEGIN_SIGNAL
    return conversation


def preprocess_multimodal(
    sources: Sequence[str],
    data_args: DataArguments
) -> Dict:
    is_multimodal = data_args.is_multimodal
    if not is_multimodal:
        return sources

    for source in sources:
        for sentence in source:
            if DEFAULT_IMAGE_TOKEN in sentence['value']:
                sentence['value'] = sentence['value'].replace(
                    DEFAULT_IMAGE_TOKEN, '').strip()
                sentence['value'] = DEFAULT_IMAGE_TOKEN + \
                    '\n' + sentence['value']
                sentence['value'] = sentence['value'].strip()
                if "mmtag" in conversation_lib.default_conversation.version:
                    sentence['value'] = sentence['value'].replace(
                        DEFAULT_IMAGE_TOKEN, '<Image>' + DEFAULT_IMAGE_TOKEN + '</Image>')
            replace_token = DEFAULT_IMAGE_TOKEN
            if data_args.mm_use_im_start_end:
                replace_token = DEFAULT_IM_START_TOKEN + replace_token + DEFAULT_IM_END_TOKEN
            sentence["value"] = sentence["value"].replace(
                DEFAULT_IMAGE_TOKEN, replace_token)

    return sources


def preprocess_llama_2(
    sources,
    tokenizer: transformers.PreTrainedTokenizer,
    has_image: bool = False
) -> Dict:
    conv = conversation_lib.default_conversation.copy()
    roles = {"human": conv.roles[0], "gpt": conv.roles[1]}

    # Apply prompt templates
    conversations = []
    for i, source in enumerate(sources):
        if roles[source[0]["from"]] != conv.roles[0]:
            # Skip the first one if it is not from human
            source = source[1:]

        conv.messages = []
        for j, sentence in enumerate(source):
            role = roles[sentence["from"]]
            assert role == conv.roles[j % 2], f"{i}"
            conv.append_message(role, sentence["value"])
        conversations.append(conv.get_prompt())

    # Tokenize conversations

    if has_image:
        input_ids = torch.stack([tokenizer_image_token(
            prompt, tokenizer, return_tensors='pt') for prompt in conversations], dim=0)
    else:
        input_ids = tokenizer(
            conversations,
            return_tensors="pt",
            padding="longest",
            max_length=tokenizer.model_max_length,
            truncation=True,
        ).input_ids

    targets = input_ids.clone()

    assert conv.sep_style == conversation_lib.SeparatorStyle.LLAMA_2

    # Mask targets
    sep = "[/INST] "
    for conversation, target in zip(conversations, targets):
        total_len = int(target.ne(tokenizer.pad_token_id).sum())

        rounds = conversation.split(conv.sep2)
        cur_len = 1
        target[:cur_len] = IGNORE_INDEX
        for i, rou in enumerate(rounds):
            if rou == "":
                break

            parts = rou.split(sep)
            if len(parts) != 2:
                break
            parts[0] += sep

            if has_image:
                round_len = len(tokenizer_image_token(rou, tokenizer))
                instruction_len = len(
                    tokenizer_image_token(parts[0], tokenizer)) - 2
            else:
                round_len = len(tokenizer(rou).input_ids)
                instruction_len = len(tokenizer(parts[0]).input_ids) - 2

            target[cur_len: cur_len + instruction_len] = IGNORE_INDEX

            cur_len += round_len
        target[cur_len:] = IGNORE_INDEX

        if cur_len < tokenizer.model_max_length:
            if cur_len != total_len:
                target[:] = IGNORE_INDEX
                print(
                    f"WARNING: tokenization mismatch: {cur_len} vs. {total_len}."
                    f" (ignored)"
                )

    return dict(
        input_ids=input_ids,
        labels=targets,
    )


def preprocess_llama3(
    sources,
    tokenizer: transformers.PreTrainedTokenizer,
    has_image: bool = False
) -> Dict:
    conv = conversation_lib.default_conversation.copy()
    roles = {"human": conv.roles[0], "gpt": conv.roles[1]}

    # Apply prompt templates
    conversations = []
    for i, source in enumerate(sources):
        if roles[source[0]["from"]] != conv.roles[0]:
            # Skip the first one if it is not from human
            source = source[1:]

        conv.messages = []
        for j, sentence in enumerate(source):
            role = roles[sentence["from"]]
            assert role == conv.roles[j % 2], f"{i}"
            conv.append_message(role, sentence["value"])
        conversations.append(conv.get_prompt())

    # Tokenize conversations

    if has_image:
        input_ids = torch.stack(
            [tokenizer_image_token(prompt, tokenizer, return_tensors='pt') for prompt in conversations], dim=0)
    else:
        input_ids = tokenizer(
            conversations,
            return_tensors="pt",
            padding="longest",
            max_length=tokenizer.model_max_length,
            truncation=True,
        ).input_ids

    targets = input_ids.clone()
    assert conv.sep_style == conversation_lib.SeparatorStyle.MPT

    # Mask targets
    sep = conv.sep + conv.roles[1]
    for conversation, target in zip(conversations, targets):
        total_len = int(target.ne(tokenizer.pad_token_id).sum())

        rounds = conversation.split(conv.sep)
        re_rounds = [conv.sep.join(rounds[:3])]
        for conv_idx in range(3, len(rounds), 2):
            re_rounds.append(conv.sep.join(rounds[conv_idx:conv_idx + 2]))
        cur_len = 0
        target[:cur_len] = IGNORE_INDEX
        for i, rou in enumerate(re_rounds):
            if rou == "":
                break

            parts = rou.split(sep)
            if len(parts) != 2:
                break
            parts[0] += sep

            if has_image:
                round_len = len(tokenizer_image_token(rou, tokenizer)) + 1
                instruction_len = len(
                    tokenizer_image_token(parts[0], tokenizer))
            else:
                round_len = len(tokenizer(rou).input_ids) + 1
                instruction_len = len(tokenizer(parts[0]).input_ids)

            if i > 0:
                round_len -= 1
                instruction_len -= 1

            target[cur_len: cur_len + instruction_len] = IGNORE_INDEX

            cur_len += round_len
        target[cur_len:] = IGNORE_INDEX

        if cur_len < tokenizer.model_max_length:
            if cur_len != total_len:
                target[:] = IGNORE_INDEX
                print(
                    f"WARNING: tokenization mismatch: {cur_len} vs. {total_len}."
                    f" (ignored)"
                )

    return dict(
        input_ids=input_ids,
        labels=targets,
    )


def preprocess_v1(
    sources,
    tokenizer: transformers.PreTrainedTokenizer,
    has_image: bool = False
) -> Dict:
    conv = conversation_lib.default_conversation.copy()
    roles = {"human": conv.roles[0], "gpt": conv.roles[1]}

    # Apply prompt templates
    conversations = []
    for i, source in enumerate(sources):
        if roles[source[0]["from"]] != conv.roles[0]:
            # Skip the first one if it is not from human
            source = source[1:]

        conv.messages = []
        for j, sentence in enumerate(source):
            role = roles[sentence["from"]]
            assert role == conv.roles[j % 2], f"{i}"
            conv.append_message(role, sentence["value"])
        conversations.append(conv.get_prompt())

    # Tokenize conversations

    if has_image:
        input_ids = torch.stack([tokenizer_image_token(
            prompt, tokenizer, return_tensors='pt') for prompt in conversations], dim=0)
    else:
        input_ids = tokenizer(
            conversations,
            return_tensors="pt",
            padding="longest",
            max_length=tokenizer.model_max_length,
            truncation=True,
        ).input_ids

    targets = input_ids.clone()

    assert conv.sep_style == conversation_lib.SeparatorStyle.TWO

    # Mask targets
    sep = conv.sep + conv.roles[1] + ": "
    for conversation, target in zip(conversations, targets):
        total_len = int(target.ne(tokenizer.pad_token_id).sum())

        rounds = conversation.split(conv.sep2)
        cur_len = 1
        target[:cur_len] = IGNORE_INDEX
        for i, rou in enumerate(rounds):
            if rou == "":
                break

            parts = rou.split(sep)
            if len(parts) != 2:
                break
            parts[0] += sep

            if has_image:
                round_len = len(tokenizer_image_token(rou, tokenizer))
                instruction_len = len(
                    tokenizer_image_token(parts[0], tokenizer)) - 2
            else:
                round_len = len(tokenizer(rou).input_ids)
                instruction_len = len(tokenizer(parts[0]).input_ids) - 2

            if i != 0 and not tokenizer.legacy and IS_TOKENIZER_GREATER_THAN_0_14:
                round_len -= 1
                instruction_len -= 1

            target[cur_len: cur_len + instruction_len] = IGNORE_INDEX

            cur_len += round_len
        target[cur_len:] = IGNORE_INDEX

        if cur_len < tokenizer.model_max_length:
            if cur_len != total_len:
                target[:] = IGNORE_INDEX
                print(
                    f"WARNING: tokenization mismatch: {cur_len} vs. {total_len}."
                    f" (ignored)"
                )

    return dict(
        input_ids=input_ids,
        labels=targets,
    )


def preprocess_mpt(
    sources,
    tokenizer: transformers.PreTrainedTokenizer,
    has_image: bool = False
) -> Dict:
    conv = conversation_lib.default_conversation.copy()
    roles = {"human": conv.roles[0], "gpt": conv.roles[1]}

    # Apply prompt templates
    conversations = []
    for i, source in enumerate(sources):
        if roles[source[0]["from"]] != conv.roles[0]:
            # Skip the first one if it is not from human
            source = source[1:]

        conv.messages = []
        for j, sentence in enumerate(source):
            role = roles[sentence["from"]]
            assert role == conv.roles[j % 2], f"{i}"
            conv.append_message(role, sentence["value"])
        conversations.append(conv.get_prompt())

    # Tokenize conversations

    if has_image:
        input_ids = torch.stack([tokenizer_image_token(
            prompt, tokenizer, return_tensors='pt') for prompt in conversations], dim=0)
    else:
        input_ids = tokenizer(
            conversations,
            return_tensors="pt",
            padding="longest",
            max_length=tokenizer.model_max_length,
            truncation=True,
        ).input_ids

    targets = input_ids.clone()
    assert conv.sep_style == conversation_lib.SeparatorStyle.MPT

    # Mask targets
    sep = conv.sep + conv.roles[1]
    for conversation, target in zip(conversations, targets):
        total_len = int(target.ne(tokenizer.pad_token_id).sum())

        rounds = conversation.split(conv.sep)
        re_rounds = [conv.sep.join(rounds[:3])]  # system + user + gpt
        for conv_idx in range(3, len(rounds), 2):
            re_rounds.append(conv.sep.join(
                rounds[conv_idx:conv_idx+2]))    # user + gpt
        cur_len = 0
        target[:cur_len] = IGNORE_INDEX
        for i, rou in enumerate(re_rounds):
            if rou == "":
                break

            parts = rou.split(sep)
            if len(parts) != 2:
                break
            parts[0] += sep

            if has_image:
                round_len = len(tokenizer_image_token(rou, tokenizer))
                instruction_len = len(
                    tokenizer_image_token(parts[0], tokenizer)) - 1
            else:
                round_len = len(tokenizer(rou).input_ids)
                instruction_len = len(tokenizer(parts[0]).input_ids) - 1

            if i != 0 and getattr(tokenizer, 'legacy', False) and IS_TOKENIZER_GREATER_THAN_0_14:
                round_len += 1
                instruction_len += 1

            target[cur_len: cur_len + instruction_len] = IGNORE_INDEX

            cur_len += round_len
        target[cur_len:] = IGNORE_INDEX

        if cur_len < tokenizer.model_max_length:
            if cur_len != total_len:
                target[:] = IGNORE_INDEX
                print(
                    f"WARNING: tokenization mismatch: {cur_len} vs. {total_len}."
                    f" (ignored)"
                )

    return dict(
        input_ids=input_ids,
        labels=targets,
    )


def preprocess_plain(
    sources: Sequence[str],
    tokenizer: transformers.PreTrainedTokenizer,
) -> Dict:
    # add end signal and concatenate together
    conversations = []
    for source in sources:
        assert len(source) == 2
        assert DEFAULT_IMAGE_TOKEN in source[0]['value']
        source[0]['value'] = DEFAULT_IMAGE_TOKEN
        conversation = source[0]['value'] + source[1]['value'] + \
            conversation_lib.default_conversation.sep
        conversations.append(conversation)
    # tokenize conversations
    input_ids = [tokenizer_image_token(
        prompt, tokenizer, return_tensors='pt') for prompt in conversations]
    targets = copy.deepcopy(input_ids)
    for target, source in zip(targets, sources):
        tokenized_len = len(tokenizer_image_token(
            source[0]['value'], tokenizer))
        target[:tokenized_len] = IGNORE_INDEX

    return dict(input_ids=input_ids, labels=targets)


def preprocess(
    sources: Sequence[str],
    tokenizer: transformers.PreTrainedTokenizer,
    has_image: bool = False
) -> Dict:
    """
    Given a list of sources, each is a conversation list. This transform:
    1. Add signal '### ' at the beginning each sentence, with end signal '\n';
    2. Concatenate conversations together;
    3. Tokenize the concatenated conversation;
    4. Make a deepcopy as the target. Mask human words with IGNORE_INDEX.
    """
    if conversation_lib.default_conversation.sep_style == conversation_lib.SeparatorStyle.PLAIN:
        return preprocess_plain(sources, tokenizer)
    if conversation_lib.default_conversation.sep_style == conversation_lib.SeparatorStyle.LLAMA_2:
        return preprocess_llama_2(sources, tokenizer, has_image=has_image)
    if conversation_lib.default_conversation.version.startswith("v1"):
        return preprocess_v1(sources, tokenizer, has_image=has_image)
    if conversation_lib.default_conversation.version == "mpt":
        return preprocess_mpt(sources, tokenizer, has_image=has_image)
    if conversation_lib.default_conversation.version == "llama3":
        return preprocess_llama3(sources, tokenizer, has_image=has_image)
    # add end signal and concatenate together
    conversations = []
    for source in sources:
        header = f"{conversation_lib.default_conversation.system}\n\n"
        conversation = _add_speaker_and_signal(header, source)
        conversations.append(conversation)
    # tokenize conversations

    def get_tokenize_len(prompts):
        return [len(tokenizer_image_token(prompt, tokenizer)) for prompt in prompts]

    if has_image:
        input_ids = [tokenizer_image_token(
            prompt, tokenizer, return_tensors='pt') for prompt in conversations]
    else:
        conversations_tokenized = _tokenize_fn(conversations, tokenizer)
        input_ids = conversations_tokenized["input_ids"]

    targets = copy.deepcopy(input_ids)
    for target, source in zip(targets, sources):
        if has_image:
            tokenized_lens = get_tokenize_len(
                [header] + [s["value"] for s in source])
        else:
            tokenized_lens = _tokenize_fn(
                [header] + [s["value"] for s in source], tokenizer)["input_ids_lens"]
        speakers = [sentence["from"] for sentence in source]
        _mask_targets(target, tokenized_lens, speakers)

    return dict(input_ids=input_ids, labels=targets)


# class LazySupervisedDataset(Dataset):
#     """Dataset for supervised fine-tuning."""

#     def __init__(self, data_path: str,
#                  tokenizer: transformers.PreTrainedTokenizer,
#                  data_args: DataArguments):
#         super(LazySupervisedDataset, self).__init__()
#         list_data_dict = json.load(open(data_path, "r"))

#         rank0_print("Formatting inputs...Skip in lazy mode")
#         self.tokenizer = tokenizer
#         self.list_data_dict = list_data_dict
#         self.data_args = data_args

#     def __len__(self):
#         return len(self.list_data_dict)

#     @property
#     def lengths(self):
#         length_list = []
#         for sample in self.list_data_dict:
#             img_tokens = 128 if 'image' in sample else 0
#             length_list.append(sum(len(conv['value'].split())
#                                for conv in sample['conversations']) + img_tokens)
#         return length_list

#     @property
#     def modality_lengths(self):
#         length_list = []
#         for sample in self.list_data_dict:
#             cur_len = sum(len(conv['value'].split())
#                           for conv in sample['conversations'])
#             cur_len = cur_len if 'image' in sample else -cur_len
#             length_list.append(cur_len)
#         return length_list

#     def __getitem__(self, i) -> Dict[str, torch.Tensor]:
#         sources = self.list_data_dict[i]
#         if isinstance(i, int):
#             sources = [sources]
#         assert len(
#             sources) == 1, "Don't know why it is wrapped to a list"  # FIXME
#         if 'image' in sources[0]:
#             image_file = self.list_data_dict[i]['image']
#             image_folder = self.data_args.image_folder
#             processor = self.data_args.image_processor
#             image = Image.open(os.path.join(
#                 image_folder, image_file)).convert('RGB')
#             if self.data_args.image_aspect_ratio == 'pad':
#                 def expand2square(pil_img, background_color):
#                     width, height = pil_img.size
#                     if width == height:
#                         return pil_img
#                     elif width > height:
#                         result = Image.new(
#                             pil_img.mode, (width, width), background_color)
#                         result.paste(pil_img, (0, (width - height) // 2))
#                         return result
#                     else:
#                         result = Image.new(
#                             pil_img.mode, (height, height), background_color)
#                         result.paste(pil_img, ((height - width) // 2, 0))
#                         return result

#                 image = expand2square(image, tuple(int(x * 255)
#                                       for x in processor.image_mean))
#                 image_size = image.size
#                 image = processor.preprocess(image, return_tensors='pt')[ #(640, 480)
#                     'pixel_values'][0]
#             elif self.data_args.image_aspect_ratio == "anyres":
#                 image_size = image.size
#                 image = process_anyres_image(       # torch.Size([5, 3, 336, 336])
#                     image, processor, self.data_args.image_grid_pinpoints)
#             else:
#                 image_size = image.size
#                 image = processor.preprocess(image, return_tensors='pt')[
#                     'pixel_values'][0]
#             sources = preprocess_multimodal(
#                 copy.deepcopy([e["conversations"] for e in sources]),
#                 self.data_args)
#         else:
#             sources = copy.deepcopy([e["conversations"] for e in sources])
#         data_dict = preprocess(
#             sources,
#             self.tokenizer,
#             has_image=('image' in self.list_data_dict[i]))
#         if isinstance(i, int):
#             data_dict = dict(input_ids=data_dict["input_ids"][0],
#                              labels=data_dict["labels"][0])

#         # image exist in the data
#         if 'image' in self.list_data_dict[i]:
#             data_dict['image'] = image
#             data_dict['image_size'] = image_size
#         elif self.data_args.is_multimodal:
#             # image does not exist in the data, but the model is multimodal
#             crop_size = self.data_args.image_processor.crop_size
#             data_dict['image'] = torch.zeros(
#                 3, crop_size['height'], crop_size['width'])
#             data_dict['image_size'] = (crop_size['height'], crop_size['width'])
#         return data_dict


# class LazySupervisedDataset(Dataset):
#     """Dataset for supervised fine-tuning.

#     支持两种情况：
#     1) data_path 指向 LLaVA 风格 JSON（原版行为不变）
#     2) data_path 指向 HF Datasets 保存目录（含 data-0000*.arrow）
#        且列为：images, texts, ...
#        texts[0] 里有 {"user": "...", "assistant": "..."}
#     """

#     def __init__(self, data_path: str,
#                  tokenizer: transformers.PreTrainedTokenizer,
#                  data_args: DataArguments):
#         super(LazySupervisedDataset, self).__init__()
#         self.tokenizer = tokenizer
#         self.data_args = data_args

#         # 1) JSON 模式：保持原逻辑
#         if os.path.isfile(data_path) and data_path.endswith(".json"):
#             rank0_print(f"Loading JSON data from {data_path}")
#             self.list_data_dict = json.load(open(data_path, "r"))
#             self.ds = None
#             return

#         # 2) HF Arrow 模式：data_path 是保存目录或其中的 dataset_dict.json
#         if os.path.isfile(data_path) and data_path.endswith("dataset_dict.json"):
#             root = os.path.dirname(data_path)
#         else:
#             root = data_path

#         rank0_print(f"Loading HF dataset (Arrow) from {root}")
#         self.ds = load_from_disk(root)  # 你的 captcha-113k 就是这个
#         self.list_data_dict = None

#         rank0_print("Formatting inputs...Skip in lazy mode (HF dataset)")

#     def __len__(self):
#         if self.ds is not None:
#             return len(self.ds)
#         return len(self.list_data_dict)

#     @property
#     def lengths(self):
#         # 只在启用 group_by_length 时用到，简单实现即可
#         length_list = []
#         if self.ds is not None:
#             for ex in self.ds:
#                 # texts: [{'user': '...', 'assistant': '...'}]
#                 t = ex["texts"][0]
#                 q_len = len(t["user"].split())
#                 a_len = len(t["assistant"].split())
#                 img_tokens = 128  # 粗略给个常数
#                 length_list.append(q_len + a_len + img_tokens)
#         else:
#             for sample in self.list_data_dict:
#                 img_tokens = 128 if 'image' in sample else 0
#                 length_list.append(sum(len(conv['value'].split())
#                                    for conv in sample['conversations']) + img_tokens)
#         return length_list

#     @property
#     def modality_lengths(self):
#         length_list = []
#         if self.ds is not None:
#             for ex in self.ds:
#                 t = ex["texts"][0]
#                 cur_len = len(t["user"].split()) + len(t["assistant"].split())
#                 # 有图，所以正号
#                 length_list.append(cur_len)
#         else:
#             for sample in self.list_data_dict:
#                 cur_len = sum(len(conv['value'].split())
#                               for conv in sample['conversations'])
#                 cur_len = cur_len if 'image' in sample else -cur_len
#                 length_list.append(cur_len)
#         return length_list

#     def _process_image(self, pil_image):
#         """复用原来的 image_aspect_ratio 逻辑，但直接用 PIL 对象，不再从路径打开。"""
#         processor = self.data_args.image_processor
#         image = pil_image.convert("RGB")
#         if self.data_args.image_aspect_ratio == 'pad':
#             def expand2square(pil_img, background_color):
#                 width, height = pil_img.size
#                 if width == height:
#                     return pil_img
#                 elif width > height:
#                     result = Image.new(
#                         pil_img.mode, (width, width), background_color)
#                     result.paste(pil_img, (0, (width - height) // 2))
#                     return result
#                 else:
#                     result = Image.new(
#                         pil_img.mode, (height, height), background_color)
#                     result.paste(pil_img, ((height - width) // 2, 0))
#                     return result

#             image = expand2square(image, tuple(int(x * 255)
#                                                for x in processor.image_mean))
#             image_size = image.size
#             image = processor.preprocess(image, return_tensors='pt')[
#                 'pixel_values'][0]
#         elif self.data_args.image_aspect_ratio == "anyres":
#             image_size = image.size
#             image = process_anyres_image(
#                 image, processor, self.data_args.image_grid_pinpoints)
#         else:
#             image_size = image.size
#             image = processor.preprocess(image, return_tensors='pt')[
#                 'pixel_values'][0]
#         return image, image_size

#     def __getitem__(self, i) -> Dict[str, torch.Tensor]:
#         # 2 分支：HF Arrow 和 原 JSON

#         # ========== 分支 A：HF Arrow 数据 ==========
#         if self.ds is not None:
#             ex = self.ds[int(i)]
#             # images: [PIL.Image]
#             pil_image = ex["images"][0]
#             # texts: [{'user': '...', 'assistant': '...'}]
#             t = ex["texts"][0]
#             user_q = t["user"]
#             assistant_a = t["assistant"]

#             # LLaVA "plain" 版本期望：
#             # 每个样本 source 长度为 2，且第一句包含 DEFAULT_IMAGE_TOKEN
#             conv = [
#                 {
#                     "from": "human",
#                     "value": DEFAULT_IMAGE_TOKEN + "\n" + user_q
#                 },
#                 {
#                     "from": "gpt",
#                     "value": assistant_a
#                 }
#             ]
#             sources = [conv]

#             # 文本预处理（多模态 + LLaVA 模板）
#             sources = preprocess_multimodal(
#                 copy.deepcopy([e for e in sources]),
#                 self.data_args
#             )
#             data_dict = preprocess(
#                 sources,
#                 self.tokenizer,
#                 has_image=True
#             )
#             # 单样本展开
#             data_dict = dict(
#                 input_ids=data_dict["input_ids"][0],
#                 labels=data_dict["labels"][0],
#             )

#             # 图像预处理
#             image, image_size = self._process_image(pil_image)
#             data_dict["image"] = image
#             data_dict["image_size"] = image_size
#             return data_dict

#         # ========== 分支 B：原来的 JSON 逻辑 ==========
#         sources = self.list_data_dict[i]
#         if isinstance(i, int):
#             sources = [sources]
#         assert len(
#             sources) == 1, "Don't know why it is wrapped to a list"  # FIXME

#         if 'image' in sources[0]:
#             image_file = self.list_data_dict[i]['image']
#             image_folder = self.data_args.image_folder
#             processor = self.data_args.image_processor
#             image = Image.open(os.path.join(
#                 image_folder, image_file)).convert('RGB')
#             if self.data_args.image_aspect_ratio == 'pad':
#                 def expand2square(pil_img, background_color):
#                     width, height = pil_img.size
#                     if width == height:
#                         return pil_img
#                     elif width > height:
#                         result = Image.new(
#                             pil_img.mode, (width, width), background_color)
#                         result.paste(pil_img, (0, (width - height) // 2))
#                         return result
#                     else:
#                         result = Image.new(
#                             pil_img.mode, (height, height), background_color)
#                         result.paste(pil_img, ((height - width) // 2, 0))
#                         return result

#                 image = expand2square(image, tuple(int(x * 255)
#                                       for x in processor.image_mean))
#                 image_size = image.size
#                 image = processor.preprocess(image, return_tensors='pt')[
#                     'pixel_values'][0]
#             elif self.data_args.image_aspect_ratio == "anyres":
#                 image_size = image.size
#                 image = process_anyres_image(
#                     image, processor, self.data_args.image_grid_pinpoints)
#             else:
#                 image_size = image.size
#                 image = processor.preprocess(image, return_tensors='pt')[
#                     'pixel_values'][0]
#             sources = preprocess_multimodal(
#                 copy.deepcopy([e["conversations"] for e in sources]),
#                 self.data_args)
#         else:
#             sources = copy.deepcopy([e["conversations"] for e in sources])

#         data_dict = preprocess(
#             sources,
#             self.tokenizer,
#             has_image=('image' in self.list_data_dict[i])
#         )
#         if isinstance(i, int):
#             data_dict = dict(input_ids=data_dict["input_ids"][0],
#                              labels=data_dict["labels"][0])

#         if 'image' in self.list_data_dict[i]:
#             data_dict['image'] = image
#             data_dict['image_size'] = image_size
#         elif self.data_args.is_multimodal:
#             crop_size = self.data_args.image_processor.crop_size
#             data_dict['image'] = torch.zeros(
#                 3, crop_size['height'], crop_size['width'])
#             data_dict['image_size'] = (crop_size['height'], crop_size['width'])
#         return data_dict


# class MMProjectorGradCallback(TrainerCallback):
#     def on_pre_optimizer_step(self, args, state, control, **kwargs):
#         model = kwargs["model"]
#         for name, p in model.named_parameters():
#             if "mm_projector" in name:
#                 if p.grad is None:
#                     print(f"[step {state.global_step}] {name} grad=None")
#                 else:
#                     grad_norm = p.grad.detach().float().norm().item()
#                     print(f"[step {state.global_step}] {name} grad_norm={grad_norm:.6f}")
#                 break  # 只打印一个参数看是否有梯度

#一轮
# class LazySupervisedDataset(Dataset):
#     """
#     Dataset for supervised fine-tuning.

#     支持两种情况：
#     1) data_path 指向 LLaVA 风格 JSON（原版行为）
#     2) data_path 指向 HF Datasets 保存目录（含 data-0000*.arrow 或 dataset_dict.json）
#        要求至少包含：images, texts 两列；
#        其中 texts[i] 为形如 {"user": "...", "assistant": "..."} 的 dict 或 [dict]。
#     """
#     def __init__(self, data_path: str,
#                  tokenizer: transformers.PreTrainedTokenizer,
#                  data_args: DataArguments):
#         super().__init__()
#         self.tokenizer = tokenizer
#         self.data_args = data_args

#         # --- 分支 1：JSON（原始行为） ---
#         if os.path.isfile(data_path) and data_path.endswith(".json"):
#             rank0_print(f"Loading JSON data from {data_path}")
#             self.list_data_dict = json.load(open(data_path, "r"))
#             self.ds = None
#             return

#         # --- 分支 2：HF Arrow（load_from_disk） ---
#         root = os.path.dirname(data_path) if (
#             os.path.isfile(data_path) and data_path.endswith("dataset_dict.json")
#         ) else data_path

#         rank0_print(f"Loading HF dataset (Arrow) from {root}")
#         ds = load_from_disk(root)  # 可能返回 Dataset 或 DatasetDict
#         # 若是 DatasetDict，优先取 train；否则合并所有 split
#         if isinstance(ds, DatasetDict):
#             if "train" in ds:
#                 ds = ds["train"]
#             else:
#                 # 将多个 split 串联
#                 from datasets import concatenate_datasets
#                 ds = concatenate_datasets([ds[k] for k in sorted(ds.keys())])

#         # 确保 images 列是 PIL（datasets.Image 特征会返回 PIL）
#         # 如果是文件路径字符串，可 cast 成 Image 再 decode
#         from datasets import Image as HFImage, Features
#         feats = ds.features
#         if "images" in feats and not isinstance(feats["images"], HFImage):
#             try:
#                 ds = ds.cast_column("images", HFImage())
#             except Exception:
#                 pass  # 如果已经是 PIL 或者 list[PIL]，则跳过

#         self.ds = ds
#         self.list_data_dict = None
#         rank0_print("Formatting inputs...Skip in lazy mode (HF dataset)")

#     def __len__(self):
#         return len(self.ds) if self.ds is not None else len(self.list_data_dict)

#     @property
#     def lengths(self):
#         # 与原版的 group_by_length 兼容：文本词数 + 粗略 img token 数
#         length_list = []
#         if self.ds is not None:
#             for ex in self.ds:
#                 t = ex["texts"]
#                 # texts 可能是 dict 或 [dict]
#                 t0 = t[0] if isinstance(t, (list, tuple)) else t
#                 q = str(t0.get("user", ""))
#                 a = str(t0.get("assistant", ""))
#                 img_tokens = 128  # 保持与原实现的“常数近似”风格
#                 length_list.append(len(q.split()) + len(a.split()) + img_tokens)
#         else:
#             for sample in self.list_data_dict:
#                 img_tokens = 128 if 'image' in sample else 0
#                 length_list.append(
#                     sum(len(conv['value'].split()) for conv in sample['conversations']) + img_tokens
#                 )
#         return length_list

#     @property
#     def modality_lengths(self):
#         # 与原版一致：有图为正，无图为负（仅用于排序/分桶）
#         length_list = []
#         if self.ds is not None:
#             for ex in self.ds:
#                 t = ex["texts"]
#                 t0 = t[0] if isinstance(t, (list, tuple)) else t
#                 cur_len = len(str(t0.get("user", "")).split()) + len(str(t0.get("assistant", "")).split())
#                 length_list.append(cur_len)  # HF 分支默认有图
#         else:
#             for sample in self.list_data_dict:
#                 cur_len = sum(len(conv['value'].split()) for conv in sample['conversations'])
#                 cur_len = cur_len if 'image' in sample else -cur_len
#                 length_list.append(cur_len)
#         return length_list

#     def _process_image(self, pil_image):
#         """严格复刻原 LLaVA 的图像管线：pad / anyres / 默认 preprocess。坏图直接返回 None。"""
#         processor = self.data_args.image_processor
#         try:
#             # 尽量把所有图像转成 RGB；如果失败视为坏图
#             image = pil_image.convert("RGB")
#         except Exception as e:
#             print(f"[WARN] Bad image (convert to RGB failed): {e}")
#             return None, None

#         try:
#             if self.data_args.image_aspect_ratio == 'pad':
#                 def expand2square(pil_img, background_color):
#                     w, h = pil_img.size
#                     if w == h:
#                         return pil_img
#                     side = max(w, h)
#                     canvas = Image.new(pil_img.mode, (side, side), background_color)
#                     canvas.paste(pil_img, ((side - w) // 2, (side - h) // 2))
#                     return canvas

#                 image = expand2square(image, tuple(int(x * 255) for x in processor.image_mean))
#                 image_size = image.size  # (W, H)
#                 image = processor.preprocess(image, return_tensors='pt')['pixel_values'][0]

#             elif self.data_args.image_aspect_ratio == "anyres":
#                 image_size = image.size
#                 image = process_anyres_image(image, processor, self.data_args.image_grid_pinpoints)

#             else:
#                 image_size = image.size
#                 image = processor.preprocess(image, return_tensors='pt')['pixel_values'][0]

#             return image, image_size

#         except Exception as e:
#             # 例如：mean/std 与通道数不匹配、decode 异常等
#             print(f"[WARN] Bad image during preprocess, skip: {e}")
#             return None, None


#     def __getitem__(self, i) -> Dict[str, torch.Tensor]:
#         try:
#             # --- 分支 A：HF Arrow ---
#             if self.ds is not None:
#                 ex = self.ds[int(i)]

#                 # images：可能是单张 PIL，也可能是 list[PIL]；与原版期望“单样本单图”对齐
#                 pil_image = ex["images"]
#                 if isinstance(pil_image, (list, tuple)):
#                     pil_image = pil_image[0]

#                 # texts：dict 或 [dict]，取第一个（保持你原逻辑不变）
#                 t = ex["texts"]
#                 t0 = t[0] if isinstance(t, (list, tuple)) else t
#                 user_q = str(t0.get("user", ""))
#                 assistant_a = str(t0.get("assistant", ""))

#                 # 构造与原 LLaVA 相同的两轮对话，并在第一轮 human 前置 DEFAULT_IMAGE_TOKEN（不改动）
#                 conv = [
#                     {"from": "human", "value": DEFAULT_IMAGE_TOKEN + "\n" + user_q},
#                     {"from": "gpt",   "value": assistant_a}
#                 ]
#                 sources = [conv]
                
                
#                 # print(f"conv = {conv}")

#                 # 文本模板 → token 化（保持原始调用顺序）
#                 sources = preprocess_multimodal(copy.deepcopy([e for e in sources]), self.data_args)
#                 data_dict = preprocess(sources, self.tokenizer, has_image=True)
#                 data_dict = dict(input_ids=data_dict["input_ids"][0],
#                                 labels=data_dict["labels"][0])

#                 # 图像处理（严格遵循 pad / anyres 的行为）
#                 image, image_size = self._process_image(pil_image)
#                 if image is None:
#                     # 坏图 → 跳过该样本，取下一条
#                     raise ValueError("Bad image sample")
#                 data_dict["image"] = image
#                 data_dict["image_size"] = image_size
#                 return data_dict

#             # --- 分支 B：原 JSON（与官方一致） ---
#             sources = self.list_data_dict[i]
#             if isinstance(i, int):
#                 sources = [sources]
#             assert len(sources) == 1, "Don't know why it is wrapped to a list"

#             if 'image' in sources[0]:
#                 image_file = self.list_data_dict[i]['image']
#                 image_folder = self.data_args.image_folder
#                 processor = self.data_args.image_processor
#                 pil_image = Image.open(os.path.join(image_folder, image_file)).convert('RGB')

#                 if self.data_args.image_aspect_ratio == 'pad':
#                     def expand2square(pil_img, background_color):
#                         w, h = pil_img.size
#                         if w == h:
#                             return pil_img
#                         side = max(w, h)
#                         canvas = Image.new(pil_img.mode, (side, side), background_color)
#                         canvas.paste(pil_img, ((side - w) // 2, (side - h) // 2))
#                         return canvas

#                     pil_image = expand2square(pil_image, tuple(int(x * 255) for x in processor.image_mean))
#                     image_size = pil_image.size
#                     image = processor.preprocess(pil_image, return_tensors='pt')['pixel_values'][0]

#                 elif self.data_args.image_aspect_ratio == "anyres":
#                     image_size = pil_image.size
#                     image = process_anyres_image(pil_image, processor, self.data_args.image_grid_pinpoints)

#                 else:
#                     image_size = pil_image.size
#                     image = processor.preprocess(pil_image, return_tensors='pt')['pixel_values'][0]

#                 # 统一用 _process_image，更稳（可选）。如果坚持不改动逻辑，保留上面的实现即可。
#                 # image, image_size = self._process_image(pil_image)
#                 # if image is None:
#                 #     raise ValueError("Bad image sample (JSON branch)")

#                 sources = preprocess_multimodal(copy.deepcopy([e["conversations"] for e in sources]),
#                                                 self.data_args)
#             else:
#                 sources = copy.deepcopy([e["conversations"] for e in sources])

#             data_dict = preprocess(sources, self.tokenizer,
#                                 has_image=('image' in self.list_data_dict[i]))
#             if isinstance(i, int):
#                 data_dict = dict(input_ids=data_dict["input_ids"][0],
#                                 labels=data_dict["labels"][0])

#             if 'image' in self.list_data_dict[i]:
#                 data_dict['image'] = image
#                 data_dict['image_size'] = image_size
#             elif self.data_args.is_multimodal:
#                 crop_size = self.data_args.image_processor.crop_size
#                 data_dict['image'] = torch.zeros(3, crop_size['height'], crop_size['width'])
#                 data_dict['image_size'] = (crop_size['height'], crop_size['width'])
#             return data_dict

#         except Exception as e:
#             # 任何样本级异常都跳过，递归取下一条（避免整个训练中断）
#             print(f"[WARN] Skipping bad sample {i}: {e}")
#             return self.__getitem__((i + 1) % len(self))


class LazySupervisedDataset(Dataset):
    """
    Dataset for supervised fine-tuning.

    支持两种情况：
    1) data_path 指向 LLaVA 风格 JSON（原版行为）
    2) data_path 指向 HF Datasets 保存目录（含 data-0000*.arrow 或 dataset_dict.json）
       要求至少包含：images, texts 两列；
       其中 texts[i] 为形如 {"user": "...", "assistant": "..."} 的 dict 或 [dict]。
    """
    def __init__(self, data_path: str,
                 tokenizer: transformers.PreTrainedTokenizer,
                 data_args: DataArguments):
        super().__init__()
        self.tokenizer = tokenizer
        self.data_args = data_args

        # --- 分支 1：JSON（原始行为） ---
        if os.path.isfile(data_path) and data_path.endswith(".json"):
            rank0_print(f"Loading JSON data from {data_path}")
            self.list_data_dict = json.load(open(data_path, "r"))
            self.ds = None
            return

        # --- 分支 2：HF Arrow（load_from_disk） ---
        root = os.path.dirname(data_path) if (
            os.path.isfile(data_path) and data_path.endswith("dataset_dict.json")
        ) else data_path

        rank0_print(f"Loading HF dataset (Arrow) from {root}")
        ds = load_from_disk(root)  # 可能返回 Dataset 或 DatasetDict
        # 若是 DatasetDict，优先取 train；否则合并所有 split
        if isinstance(ds, DatasetDict):
            if "train" in ds:
                ds = ds["train"]
            else:
                # 将多个 split 串联
                from datasets import concatenate_datasets
                ds = concatenate_datasets([ds[k] for k in sorted(ds.keys())])

        # 确保 images 列是 PIL（datasets.Image 特征会返回 PIL）
        # 如果是文件路径字符串，可 cast 成 Image 再 decode
        from datasets import Image as HFImage, Features
        feats = ds.features
        if "images" in feats and not isinstance(feats["images"], HFImage):
            try:
                ds = ds.cast_column("images", HFImage())
            except Exception:
                pass  # 如果已经是 PIL 或者 list[PIL]，则跳过

        self.ds = ds
        self.list_data_dict = None
        rank0_print("Formatting inputs...Skip in lazy mode (HF dataset)")

    def __len__(self):
        return len(self.ds) if self.ds is not None else len(self.list_data_dict)

    @property
    def lengths(self):
        # 与原版的 group_by_length 兼容：文本词数 + 粗略 img token 数
        length_list = []
        if self.ds is not None:
            for ex in self.ds:
                t = ex["texts"]
                # texts 可能是 dict 或 [dict]
                t0 = t[0] if isinstance(t, (list, tuple)) else t
                q = str(t0.get("user", ""))
                a = str(t0.get("assistant", ""))
                img_tokens = 128  # 保持与原实现的“常数近似”风格
                length_list.append(len(q.split()) + len(a.split()) + img_tokens)
        else:
            for sample in self.list_data_dict:
                img_tokens = 128 if 'image' in sample else 0
                length_list.append(
                    sum(len(conv['value'].split()) for conv in sample['conversations']) + img_tokens
                )
        return length_list

    @property
    def modality_lengths(self):
        # 与原版一致：有图为正，无图为负（仅用于排序/分桶）
        length_list = []
        if self.ds is not None:
            for ex in self.ds:
                t = ex["texts"]
                t0 = t[0] if isinstance(t, (list, tuple)) else t
                cur_len = len(str(t0.get("user", "")).split()) + len(str(t0.get("assistant", "")).split())
                length_list.append(cur_len)  # HF 分支默认有图
        else:
            for sample in self.list_data_dict:
                cur_len = sum(len(conv['value'].split()) for conv in sample['conversations'])
                cur_len = cur_len if 'image' in sample else -cur_len
                length_list.append(cur_len)
        return length_list

    def _process_image(self, pil_image):
        """严格复刻原 LLaVA 的图像管线：pad / anyres / 默认 preprocess。坏图直接返回 None。"""
        processor = self.data_args.image_processor
        try:
            # 尽量把所有图像转成 RGB；如果失败视为坏图
            image = pil_image.convert("RGB")
        except Exception as e:
            print(f"[WARN] Bad image (convert to RGB failed): {e}")
            return None, None

        try:
            if self.data_args.image_aspect_ratio == 'pad':
                def expand2square(pil_img, background_color):
                    w, h = pil_img.size
                    if w == h:
                        return pil_img
                    side = max(w, h)
                    canvas = Image.new(pil_img.mode, (side, side), background_color)
                    canvas.paste(pil_img, ((side - w) // 2, (side - h) // 2))
                    return canvas

                image = expand2square(image, tuple(int(x * 255) for x in processor.image_mean))
                image_size = image.size  # (W, H)
                image = processor.preprocess(image, return_tensors='pt')['pixel_values'][0]

            elif self.data_args.image_aspect_ratio == "anyres":
                image_size = image.size
                image = process_anyres_image(image, processor, self.data_args.image_grid_pinpoints)

            else:
                image_size = image.size
                image = processor.preprocess(image, return_tensors='pt')['pixel_values'][0]

            return image, image_size

        except Exception as e:
            # 例如：mean/std 与通道数不匹配、decode 异常等
            print(f"[WARN] Bad image during preprocess, skip: {e}")
            return None, None


    def __getitem__(self, i) -> Dict[str, torch.Tensor]:
        try:
            # --- 分支 A：HF Arrow ---
            if self.ds is not None:
                ex = self.ds[int(i)]

                # images：可能是单张 PIL，也可能是 list[PIL]；与原版期望“单样本单图”对齐
                pil_image = ex["images"]
                if isinstance(pil_image, (list, tuple)):
                    pil_image = pil_image[0]

                # ✅ texts：可能是 dict 或 [dict]；这里改成“取全部轮次”
                t = ex["texts"]
                t_list = list(t) if isinstance(t, (list, tuple)) else [t]

                # 构造多轮对话：第 1 轮 human 前置 DEFAULT_IMAGE_TOKEN，其余轮不加（别的逻辑不变）
                conv = []
                for turn_idx, turn in enumerate(t_list):
                    user_q = str(turn.get("user", ""))
                    assistant_a = str(turn.get("assistant", ""))

                    if turn_idx == 0:
                        human_val = DEFAULT_IMAGE_TOKEN + "\n" + user_q
                    else:
                        human_val = user_q

                    conv.append({"from": "human", "value": human_val})
                    conv.append({"from": "gpt",   "value": assistant_a})

                sources = [conv]
                # print(sources)

                # 文本模板 → token 化（保持原始调用顺序）
                sources = preprocess_multimodal(copy.deepcopy([e for e in sources]), self.data_args)
                data_dict = preprocess(sources, self.tokenizer, has_image=True)
                data_dict = dict(input_ids=data_dict["input_ids"][0],
                                labels=data_dict["labels"][0])

                # 图像处理（严格遵循 pad / anyres 的行为）
                image, image_size = self._process_image(pil_image)
                if image is None:
                    # 坏图 → 跳过该样本，取下一条
                    raise ValueError("Bad image sample")
                data_dict["image"] = image
                data_dict["image_size"] = image_size
                return data_dict

            # --- 分支 B：原 JSON（与官方一致） ---
            sources = self.list_data_dict[i]
            if isinstance(i, int):
                sources = [sources]
            assert len(sources) == 1, "Don't know why it is wrapped to a list"

            if 'image' in sources[0]:
                image_file = self.list_data_dict[i]['image']
                image_folder = self.data_args.image_folder
                processor = self.data_args.image_processor
                pil_image = Image.open(os.path.join(image_folder, image_file)).convert('RGB')

                if self.data_args.image_aspect_ratio == 'pad':
                    def expand2square(pil_img, background_color):
                        w, h = pil_img.size
                        if w == h:
                            return pil_img
                        side = max(w, h)
                        canvas = Image.new(pil_img.mode, (side, side), background_color)
                        canvas.paste(pil_img, ((side - w) // 2, (side - h) // 2))
                        return canvas

                    pil_image = expand2square(pil_image, tuple(int(x * 255) for x in processor.image_mean))
                    image_size = pil_image.size
                    image = processor.preprocess(pil_image, return_tensors='pt')['pixel_values'][0]

                elif self.data_args.image_aspect_ratio == "anyres":
                    image_size = pil_image.size
                    image = process_anyres_image(pil_image, processor, self.data_args.image_grid_pinpoints)

                else:
                    image_size = pil_image.size
                    image = processor.preprocess(pil_image, return_tensors='pt')['pixel_values'][0]

                sources = preprocess_multimodal(copy.deepcopy([e["conversations"] for e in sources]),
                                                self.data_args)
            else:
                sources = copy.deepcopy([e["conversations"] for e in sources])

            data_dict = preprocess(sources, self.tokenizer,
                                has_image=('image' in self.list_data_dict[i]))
            if isinstance(i, int):
                data_dict = dict(input_ids=data_dict["input_ids"][0],
                                labels=data_dict["labels"][0])

            if 'image' in self.list_data_dict[i]:
                data_dict['image'] = image
                data_dict['image_size'] = image_size
            elif self.data_args.is_multimodal:
                crop_size = self.data_args.image_processor.crop_size
                data_dict['image'] = torch.zeros(3, crop_size['height'], crop_size['width'])
                data_dict['image_size'] = (crop_size['height'], crop_size['width'])
            return data_dict

        except Exception as e:
            # 任何样本级异常都跳过，递归取下一条（避免整个训练中断）
            print(f"[WARN] Skipping bad sample {i}: {e}")
            return self.__getitem__((i + 1) % len(self))



    
@dataclass
class DataCollatorForSupervisedDataset(object):
    """Collate examples for supervised fine-tuning."""

    tokenizer: transformers.PreTrainedTokenizer

    def __call__(self, instances: Sequence[Dict]) -> Dict[str, torch.Tensor]:
        input_ids, labels = tuple([instance[key] for instance in instances]
                                  for key in ("input_ids", "labels"))
        input_ids = torch.nn.utils.rnn.pad_sequence(
            input_ids,
            batch_first=True,
            padding_value=self.tokenizer.pad_token_id)
        labels = torch.nn.utils.rnn.pad_sequence(labels,
                                                 batch_first=True,
                                                 padding_value=IGNORE_INDEX)
        input_ids = input_ids[:, :self.tokenizer.model_max_length]
        labels = labels[:, :self.tokenizer.model_max_length]
        batch = dict(
            input_ids=input_ids,
            labels=labels,
            attention_mask=input_ids.ne(self.tokenizer.pad_token_id),
        )

        if 'image' in instances[0]:
            images = [instance['image'] for instance in instances]
            image_sizes = [instance['image_size'] for instance in instances]
            if all(x is not None and x.shape == images[0].shape for x in images):
                batch['images'] = torch.stack(images)
            else:
                batch['images'] = images
            batch['image_sizes'] = image_sizes

        return batch


def make_supervised_data_module(tokenizer: transformers.PreTrainedTokenizer,
                                data_args) -> Dict:
    """Make dataset and collator for supervised fine-tuning."""
    train_dataset = LazySupervisedDataset(tokenizer=tokenizer,
                                          data_path=data_args.data_path,
                                          data_args=data_args)
    # ex = train_dataset.ds[0]
    # print("=== Example 0 raw ===")
    # print(ex)
    # print("=== Example 0 texts ===")
    # print(ex["texts"])
    data_collator = DataCollatorForSupervisedDataset(tokenizer=tokenizer)
    return dict(train_dataset=train_dataset,
                eval_dataset=None,
                data_collator=data_collator)


def unfreeze_vit(vision_tower):
    for _, p in vision_tower.named_parameters():
        p.requires_grad = True


def format_bytes(size):
    billion = 10**9
    million = 10**6

    if size >= billion:
        return f"{size / billion:.2f}B"
    elif size >= million:
        return f"{size / million:.2f}M"
    else:
        return f"{size} bytes"


def train(attn_implementation=None):
    global local_rank

    parser = transformers.HfArgumentParser(
        (ModelArguments, DataArguments, TrainingArguments))
    model_args, data_args, training_args = parser.parse_args_into_dataclasses()
    local_rank = training_args.local_rank
    compute_dtype = (torch.float16 if training_args.fp16 else (
        torch.bfloat16 if training_args.bf16 else torch.float32))

    bnb_model_from_pretrained_args = {}
    if training_args.bits in [4, 8]:
        from transformers import BitsAndBytesConfig
        bnb_model_from_pretrained_args.update(dict(
            device_map={"": training_args.device},
            load_in_4bit=training_args.bits == 4,
            load_in_8bit=training_args.bits == 8,
            quantization_config=BitsAndBytesConfig(
                load_in_4bit=training_args.bits == 4,
                load_in_8bit=training_args.bits == 8,
                llm_int8_skip_modules=["mm_projector"],
                llm_int8_threshold=6.0,
                llm_int8_has_fp16_weight=False,
                bnb_4bit_compute_dtype=compute_dtype,
                bnb_4bit_use_double_quant=training_args.double_quant,
                bnb_4bit_quant_type=training_args.quant_type  # {'fp4', 'nf4'}
            )
        ))
    model_max_length_args = {}
    if 'llava-v1.6-8b' not in model_args.model_name_or_path:
        config = transformers.AutoConfig.from_pretrained(
            model_args.model_name_or_path, trust_remote_code=True)
        if config.max_position_embeddings < training_args.model_max_length:
            rank0_print(
                f'Set the max_position_embeddings from {config.max_position_embeddings} to {training_args.model_max_length}')
            model_max_length_args.update(
                {'max_position_embeddings': training_args.model_max_length})
    if model_args.vision_tower is not None:
        if 'mpt' in model_args.model_name_or_path:
            config = transformers.AutoConfig.from_pretrained(
                model_args.model_name_or_path, trust_remote_code=True)
            config.attn_config['attn_impl'] = training_args.mpt_attn_impl
            model = LlavaMptForCausalLM.from_pretrained(
                model_args.model_name_or_path,
                config=config,
                cache_dir=training_args.cache_dir,
                **bnb_model_from_pretrained_args
            )
        else:
            model = LlavaLlamaForCausalLM.from_pretrained(
                model_args.model_name_or_path,
                cache_dir=training_args.cache_dir,
                attn_implementation=attn_implementation,
                torch_dtype=(torch.bfloat16 if training_args.bf16 else None),
                **bnb_model_from_pretrained_args,
                **model_max_length_args
            )
    else:
        model = transformers.LlamaForCausalLM.from_pretrained(
            model_args.model_name_or_path,
            cache_dir=training_args.cache_dir,
            attn_implementation=attn_implementation,
            torch_dtype=(torch.bfloat16 if training_args.bf16 else None),
            **bnb_model_from_pretrained_args
        )
    model.config.use_cache = False

    if model_args.freeze_backbone:
        model.model.requires_grad_(False)

    if training_args.bits in [4, 8]:
        from peft import prepare_model_for_kbit_training
        model.config.torch_dtype = (torch.float32 if training_args.fp16 else (
            torch.bfloat16 if training_args.bf16 else torch.float32))
        model = prepare_model_for_kbit_training(
            model, use_gradient_checkpointing=training_args.gradient_checkpointing)

    if training_args.gradient_checkpointing:
        if hasattr(model, "enable_input_require_grads"):
            model.enable_input_require_grads()
        else:
            def make_inputs_require_grad(module, input, output):
                output.requires_grad_(True)
            model.get_input_embeddings().register_forward_hook(make_inputs_require_grad)

    if training_args.lora_enable:
        from peft import LoraConfig, get_peft_model
        lora_config = LoraConfig(
            r=training_args.lora_r,
            lora_alpha=training_args.lora_alpha,
            target_modules=find_all_linear_names(model, training_args.lora_qv_proj_only),
            lora_dropout=training_args.lora_dropout,
            bias=training_args.lora_bias,
            task_type="CAUSAL_LM",
        )
        if training_args.bits == 16:
            if training_args.bf16:
                model.to(torch.bfloat16)
            if training_args.fp16:
                model.to(torch.float16)
        rank0_print("Adding LoRA adapters...")
        model = get_peft_model(model, lora_config)

    if 'mpt' in model_args.model_name_or_path:
        tokenizer = transformers.AutoTokenizer.from_pretrained(
            model_args.model_name_or_path,
            cache_dir=training_args.cache_dir,
            model_max_length=training_args.model_max_length,
            padding_side="right"
        )
    else:
        tokenizer = transformers.AutoTokenizer.from_pretrained(
            model_args.model_name_or_path,
            cache_dir=training_args.cache_dir,
            model_max_length=training_args.model_max_length,
            padding_side="right",
            use_fast=False,
        )

    if model_args.version == "v0":
        if tokenizer.pad_token is None:
            smart_tokenizer_and_embedding_resize(
                special_tokens_dict=dict(pad_token="[PAD]"),
                tokenizer=tokenizer,
                model=model,
            )
    elif model_args.version == "v0.5":
        tokenizer.pad_token = tokenizer.unk_token
    else:
        if tokenizer.pad_token is None:
            rank0_print("Adding pad token as '<pad>'")
            smart_tokenizer_and_embedding_resize(
                special_tokens_dict=dict(pad_token="<pad>"),
                tokenizer=tokenizer,
                model=model,
            )
        if model_args.version in conversation_lib.conv_templates:
            conversation_lib.default_conversation = conversation_lib.conv_templates[
                model_args.version]
        else:
            conversation_lib.default_conversation = conversation_lib.conv_templates["vicuna_v1"]

    if model_args.vision_tower is not None:
        model.get_model().initialize_vision_modules(
            model_args=model_args,
            fsdp=training_args.fsdp
        )

        vision_tower = model.get_vision_tower()
        vision_tower.to(
            dtype=torch.bfloat16 if training_args.bf16 else torch.float16, device=training_args.device)

        data_args.image_processor = vision_tower.image_processor
        data_args.is_multimodal = True

        model.config.image_aspect_ratio = data_args.image_aspect_ratio
        if data_args.image_aspect_ratio == 'anyres':
            base_size = vision_tower.config.image_size
            grids = [[1, 2], [2, 1], [2, 2], [3, 1], [1, 3]]
            model.config.image_grid_pinpoints = data_args.image_grid_pinpoints = [
                [g[0]*base_size, g[1]*base_size] for g in grids]
        model.config.tokenizer_padding_side = tokenizer.padding_side
        model.config.tokenizer_model_max_length = tokenizer.model_max_length

        model.config.tune_mm_mlp_adapter = training_args.tune_mm_mlp_adapter = model_args.tune_mm_mlp_adapter
        if model_args.tune_mm_mlp_adapter:
            model.requires_grad_(False)
            for p in model.get_model().mm_projector.parameters():
                p.requires_grad = True

        model.config.freeze_mm_mlp_adapter = training_args.freeze_mm_mlp_adapter
        if training_args.freeze_mm_mlp_adapter:
            for p in model.get_model().mm_projector.parameters():
                p.requires_grad = False

        model.config.unfreeze_mm_vision_tower = training_args.unfreeze_mm_vision_tower
        if training_args.unfreeze_mm_vision_tower:
            lr_of_vit = training_args.mm_vision_tower_lr if training_args.mm_vision_tower_lr is not None else training_args.learning_rate
            lr_of_mlp = training_args.mm_projector_lr if training_args.mm_projector_lr is not None else training_args.learning_rate
            training_args.mm_projector_lr = lr_of_mlp
            unfreeze_vit(vision_tower)
            rank0_print(
                f'Tune the entire model! The LR of ViT is {lr_of_vit}. The LR of MLP is {lr_of_mlp}. The LR of LLM is {training_args.learning_rate}')

        # Calculate total parameters and trainable parameters
        total_params = sum(p.numel() for p in model.get_model().parameters())
        trainable_params = sum(
            p.numel() for p in model.get_model().parameters() if p.requires_grad)

        rank0_print(f"Total parameters: {format_bytes(total_params)}")
        rank0_print(f"Trainable parameters: {format_bytes(trainable_params)}")

        if training_args.bits in [4, 8]:
            model.get_model().mm_projector.to(dtype=compute_dtype, device=training_args.device)

        model.config.mm_use_im_start_end = data_args.mm_use_im_start_end = model_args.mm_use_im_start_end
        model.config.mm_projector_lr = training_args.mm_projector_lr
        model.config.mm_vision_tower_lr = training_args.mm_vision_tower_lr
        training_args.use_im_start_end = model_args.mm_use_im_start_end
        model.config.mm_use_im_patch_token = model_args.mm_use_im_patch_token
        model.initialize_vision_tokenizer(model_args, tokenizer=tokenizer)
        model.config.pad_token_id = tokenizer.pad_token_id

    if training_args.bits in [4, 8]:
        from peft.tuners.lora import LoraLayer
        for name, module in model.named_modules():
            if isinstance(module, LoraLayer):
                if training_args.bf16:
                    module = module.to(torch.bfloat16)
            if 'norm' in name:
                module = module.to(torch.float32)
            if 'lm_head' in name or 'embed_tokens' in name:
                if hasattr(module, 'weight'):
                    if training_args.bf16 and module.weight.dtype == torch.float32:
                        module = module.to(torch.bfloat16)

    data_module = make_supervised_data_module(tokenizer=tokenizer,
                                              data_args=data_args)
    trainer = LLaVATrainer(model=model,
                           tokenizer=tokenizer,
                           args=training_args,
                           **data_module)
    
    

    if list(pathlib.Path(training_args.output_dir).glob("checkpoint-*")):
        trainer.train(resume_from_checkpoint=True)
    else:
        trainer.train()
    trainer.save_state()

    model.config.use_cache = True

    if training_args.lora_enable:
        state_dict = get_peft_state_maybe_zero_3(
            model.named_parameters(), training_args.lora_bias
        )
        non_lora_state_dict = get_peft_state_non_lora_maybe_zero_3(
            model.named_parameters()
        )
        if training_args.local_rank == 0 or training_args.local_rank == -1:
            model.config.save_pretrained(training_args.output_dir)
            model.save_pretrained(
                training_args.output_dir, state_dict=state_dict)
            torch.save(non_lora_state_dict, os.path.join(
                training_args.output_dir, 'non_lora_trainables.bin'))
    else:
        safe_save_model_for_hf_trainer(trainer=trainer,
                                       output_dir=training_args.output_dir)


if __name__ == "__main__":
    train()

#!/bin/bash
set -euo pipefail
CONFIG_PATH="${1:-/workspace/pipeline.yaml}"
cd /workspace
conda run --no-capture-output -n train python run_train_eval.py --config "$CONFIG_PATH"

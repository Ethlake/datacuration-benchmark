from __future__ import annotations

import argparse
from pathlib import Path

from data.data import download_extract
from model.model import download_model
from pipeline_utils import ensure_parent_dirs, load_config, pretty_paths, resolve_paths, validate_config


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Download dataset and model assets from pipeline.yaml")
    parser.add_argument("--config", default="pipeline.yaml", help="Path to pipeline.yaml")
    return parser.parse_args()



def main() -> None:
    args = parse_args()
    cfg, config_path, project_root = load_config(args.config)
    paths = resolve_paths(cfg, config_path.parent, project_root)
    validate_config(cfg, paths)
    ensure_parent_dirs(paths)

    print("[Prepare] project_root:", project_root)
    print("[Prepare] resolved paths:\n" + pretty_paths(paths))

    downloads = cfg["downloads"]
    dataset_id = downloads["dataset_id"]
    dataset_dir = download_extract(dataset_id, paths["data_root"])
    print(f"[Prepare] dataset ready: {dataset_dir}")

    for model_id in downloads["model_ids"]:
        model_dir = download_model(model_id, paths["model_root"])
        print(f"[Prepare] model ready: {model_dir}")

    print("\n[Prepare] Done.")
    print(f"[Prepare] dataset json: {paths['dataset_json_path']}")
    print(f"[Prepare] image root:   {paths['image_root']}")
    print(f"[Prepare] vicuna path:  {paths['vicuna_path']}")
    print(f"[Prepare] vision path:  {paths['vision_tower_path']}")
    print(f"[Prepare] projector:    {paths['mm_projector_path']}")


if __name__ == "__main__":
    main()

"""
data.py

Utility functions for downloading and extracting datasets to local disk.
"""

import argparse
import os
import shutil
from pathlib import Path
from typing import Dict, List, TypedDict
from zipfile import ZipFile

import requests
from PIL import Image
from rich.progress import (
    BarColumn,
    DownloadColumn,
    MofNCompleteColumn,
    Progress,
    TextColumn,
    TransferSpeedColumn,
)
from tqdm import tqdm


DatasetComponent = TypedDict(
    "DatasetComponent",
    {"name": str, "extract": bool, "extract_type": str, "url": str, "do_rename": bool},
    total=False,
)

DATASET_REGISTRY: Dict[str, List[DatasetComponent]] = {
    "llava-laion-cc-sbu-558k": [
        {
            "name": "chat.json",
            "extract": False,
            "url": "https://huggingface.co/datasets/liuhaotian/LLaVA-Pretrain/resolve/main/blip_laion_cc_sbu_558k.json",
            "do_rename": True,
        },
        {
            "name": "images",
            "extract": True,
            "extract_type": "directory",
            "url": "https://huggingface.co/datasets/liuhaotian/LLaVA-Pretrain/resolve/main/images.zip",
            "do_rename": False,
        },
    ],
    "llava-v1.5-instruct": [
        {
            "name": "llava_v1_5_mix665k.json",
            "extract": False,
            "url": "https://huggingface.co/datasets/liuhaotian/LLaVA-Instruct-150K/resolve/main/llava_v1_5_mix665k.json",
            "do_rename": True,
        },
        {
            "name": "coco/train2017",
            "extract": True,
            "extract_type": "directory",
            "url": "http://images.cocodataset.org/zips/train2017.zip",
            "do_rename": True,
        },
        {
            "name": "gqa/images",
            "extract": True,
            "extract_type": "directory",
            "url": "https://downloads.cs.stanford.edu/nlp/data/gqa/images.zip",
            "do_rename": True,
        },
        {
            "name": "ocr_vqa/images",
            "extract": True,
            "extract_type": "directory",
            "url": "https://huggingface.co/datasets/qnguyen3/ocr_vqa/resolve/main/ocr_vqa.zip",
            "do_rename": True,
        },
        {
            "name": "textvqa/train_images",
            "extract": True,
            "extract_type": "directory",
            "url": "https://dl.fbaipublicfiles.com/textvqa/images/train_val_images.zip",
            "do_rename": True,
        },
        {
            "name": "vg/VG_100K",
            "extract": True,
            "extract_type": "directory",
            "url": "https://cs.stanford.edu/people/rak248/VG_100K_2/images.zip",
            "do_rename": True,
        },
        {
            "name": "vg/VG_100K_2",
            "extract": True,
            "extract_type": "directory",
            "url": "https://cs.stanford.edu/people/rak248/VG_100K_2/images2.zip",
            "do_rename": True,
        },
    ],
}



def convert_to_jpg(image_dir: Path) -> None:
    print(f"Converting all images in `{image_dir}` to JPG")
    if not image_dir.exists():
        raise FileNotFoundError(f"Image directory does not exist: {image_dir}")

    for image_fn in tqdm(list(image_dir.iterdir())):
        if image_fn.suffix.lower() in {".jpg", ".jpeg"}:
            continue
        jpg_fn = image_dir / f"{image_fn.stem}.jpg"
        if jpg_fn.exists():
            continue
        suffix = image_fn.suffix.lower()
        if suffix == ".gif":
            gif = Image.open(image_fn)
            gif.seek(0)
            gif.convert("RGB").save(jpg_fn)
        elif suffix == ".png":
            Image.open(image_fn).convert("RGB").save(jpg_fn)
        else:
            raise ValueError(f"Unexpected image format `{image_fn.suffix}` in {image_fn}")



def download_with_progress(url: str, download_dir: Path, chunk_size_bytes: int = 1024) -> Path:
    download_dir.mkdir(parents=True, exist_ok=True)
    dest_path = download_dir / Path(url).name
    print(f"Downloading `{dest_path}` from `{url}`")
    if dest_path.exists():
        print(f"File already exists, skipping download: {dest_path}")
        return dest_path

    response = requests.get(url, stream=True, timeout=60)
    response.raise_for_status()
    total_size = response.headers.get("content-length")
    total_size_int = int(total_size) if total_size is not None else None

    with Progress(
        TextColumn("[bold]{task.description} - {task.fields[fname]}"),
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>3.1f}%",
        "•",
        DownloadColumn(),
        "•",
        TransferSpeedColumn(),
        transient=True,
    ) as dl_progress:
        dl_tid = dl_progress.add_task("Downloading", fname=dest_path.name, total=total_size_int)
        with open(dest_path, "wb") as f:
            for data in response.iter_content(chunk_size=chunk_size_bytes):
                if not data:
                    continue
                written = f.write(data)
                dl_progress.advance(dl_tid, written)

    return dest_path



def extract_with_progress(archive_path: Path, download_dir: Path, extract_type: str, cleanup: bool = False) -> Path:
    if archive_path.suffix.lower() != ".zip":
        raise AssertionError("Only `.zip` compressed archives are supported for now!")

    print(f"Extracting `{archive_path.name}` to `{download_dir}`")
    with Progress(
        TextColumn("[bold]{task.description} - {task.fields[aname]}"),
        BarColumn(bar_width=None),
        "[progress.percentage]{task.percentage:>3.1f}%",
        "•",
        MofNCompleteColumn(),
        transient=True,
    ) as ext_progress:
        with ZipFile(archive_path) as zf:
            members = zf.infolist()
            ext_tid = ext_progress.add_task("Extracting", aname=archive_path.name, total=len(members))
            if len(members) == 0:
                raise ValueError(f"Archive is empty: {archive_path}")

            first_member_path = Path(zf.extract(members[0], download_dir))
            ext_progress.advance(ext_tid)

            if extract_type == "file":
                if len(members) != 1:
                    raise AssertionError(f"Archive `{archive_path}` with extract type `{extract_type}` has > 1 member!")
                extract_path = first_member_path
            elif extract_type == "directory":
                for member in members[1:]:
                    zf.extract(member, download_dir)
                    ext_progress.advance(ext_tid)
                extract_path = first_member_path.parent if first_member_path.is_file() else first_member_path
            else:
                raise ValueError(f"Extract type `{extract_type}` for archive `{archive_path}` is not defined!")

    if cleanup:
        archive_path.unlink()
    return extract_path



def _ensure_dataset_exists(dataset_id: str) -> None:
    if dataset_id not in DATASET_REGISTRY:
        available = ", ".join(sorted(DATASET_REGISTRY.keys()))
        raise ValueError(f"Unknown dataset_id `{dataset_id}`. Available dataset_ids: {available}")



def download_extract(dataset_id: str, root_dir: Path) -> Path:
    _ensure_dataset_exists(dataset_id)
    root_dir = Path(root_dir).resolve()
    download_dir = root_dir / "download" / dataset_id
    os.makedirs(download_dir, exist_ok=True)

    print(f"Preparing dataset `{dataset_id}` in `{download_dir}`")
    for component in DATASET_REGISTRY[dataset_id]:
        target = download_dir / component["name"]
        if target.exists():
            print(f"Component already exists, skipping: {target}")
            continue

        dl_path = download_with_progress(component["url"], download_dir)
        if component.get("extract", False):
            dl_path = extract_with_progress(dl_path, download_dir, component["extract_type"])
            dl_path = dl_path.parent if dl_path.is_file() else dl_path

        if component.get("do_rename", False):
            target.parent.mkdir(parents=True, exist_ok=True)
            if not target.exists():
                shutil.move(str(dl_path), str(target))

    print(f"Finished preparing dataset `{dataset_id}` at `{download_dir}`")
    return download_dir



def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Download and extract registered datasets.")
    parser.add_argument("--dataset-id", type=str, required=True)
    parser.add_argument("--root-dir", type=str, default=str(Path(__file__).resolve().parent))
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    final_dir = download_extract(args.dataset_id, Path(args.root_dir).resolve())
    print(f"\nDataset ready at: {final_dir}")

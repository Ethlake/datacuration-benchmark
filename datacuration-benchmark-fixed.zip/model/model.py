"""
model.py

Utility functions for downloading model weights into local disk.
"""

import argparse
from pathlib import Path
from typing import Dict, TypedDict

from huggingface_hub import snapshot_download


ModelComponent = TypedDict("ModelComponent", {"name": str, "repo": str})

MODEL_REGISTRY: Dict[str, ModelComponent] = {
    "llava-v1.5-mlp2x-336px-pretrain-vicuna-7b-v1.5": {
        "name": "llava-v1.5-mlp2x-336px-pretrain-vicuna-7b-v1.5",
        "repo": "liuhaotian/llava-v1.5-mlp2x-336px-pretrain-vicuna-7b-v1.5",
    },
    "vicuna-7b-v1.5": {
        "name": "vicuna-7b-v1.5",
        "repo": "lmsys/vicuna-7b-v1.5",
    },
    "clip-vit-large-patch14-336": {
        "name": "clip-vit-large-patch14-336",
        "repo": "openai/clip-vit-large-patch14-336",
    },
}



def _ensure_model_exists(model_id: str) -> None:
    if model_id not in MODEL_REGISTRY:
        available = ", ".join(sorted(MODEL_REGISTRY.keys()))
        raise ValueError(f"Unknown model_id `{model_id}`. Available model_ids: {available}, or use `all`.")



def download_model(model_id: str, root_dir: Path) -> Path:
    _ensure_model_exists(model_id)

    root_dir = Path(root_dir).resolve()
    download_root = root_dir / "download"
    download_root.mkdir(parents=True, exist_ok=True)

    model_info = MODEL_REGISTRY[model_id]
    model_name = model_info["name"]
    repo_id = model_info["repo"]
    target_dir = download_root / model_name

    if target_dir.exists() and any(target_dir.iterdir()):
        print(f"Model already exists, skipping download: {target_dir}")
        return target_dir

    print(f"Preparing model `{model_id}` in `{target_dir}`")
    snapshot_download(
        repo_id=repo_id,
        local_dir=target_dir,
        local_dir_use_symlinks=False,
        resume_download=True,
    )
    print(f"Finished preparing model `{model_id}` at `{target_dir}`")
    return target_dir



def download_all_models(root_dir: Path) -> Dict[str, Path]:
    return {model_id: download_model(model_id, root_dir) for model_id in MODEL_REGISTRY}



def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Download model weights from MODEL_REGISTRY.")
    parser.add_argument("--model-id", type=str, required=True, help="Model ID from MODEL_REGISTRY, or `all`.")
    parser.add_argument("--root-dir", type=str, default=str(Path(__file__).resolve().parent))
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    root_dir = Path(args.root_dir).resolve()
    if args.model_id == "all":
        results = download_all_models(root_dir)
        print("\nAll models ready:")
        for mid, path in results.items():
            print(f"  - {mid}: {path}")
    else:
        final_dir = download_model(args.model_id, root_dir)
        print(f"\nModel ready at: {final_dir}")

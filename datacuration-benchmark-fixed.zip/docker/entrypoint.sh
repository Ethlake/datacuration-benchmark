#!/bin/bash
set -e

source /opt/conda/etc/profile.d/conda.sh

mkdir -p /workspace/.cache/huggingface || true

echo "Container started."
echo "PWD: $(pwd)"
echo "Available conda envs:"
conda env list || true

echo "Useful commands:"
echo "  run_prepare.sh /workspace/pipeline.yaml"
echo "  run_train_eval.sh /workspace/pipeline.yaml"

exec "$@"

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compatibility wrapper for the new 2-step pipeline")
    parser.add_argument("--config", default="pipeline.yaml")
    return parser.parse_args()



def main() -> None:
    args = parse_args()
    project_root = Path(__file__).resolve().parent

    print("[run_pipeline.py] 这个入口现在只是兼容包装。")
    print("[run_pipeline.py] 实际推荐你分两步执行：")
    print("  1) python prepare_assets.py --config pipeline.yaml")
    print("  2) python run_train_eval.py --config pipeline.yaml")

    subprocess.run([sys.executable, str(project_root / "prepare_assets.py"), "--config", args.config], check=True)
    subprocess.run([sys.executable, str(project_root / "run_train_eval.py"), "--config", args.config], check=True)


if __name__ == "__main__":
    main()
